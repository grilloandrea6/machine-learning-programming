function [] = display_deck(deck, unique_cards)
disp(unique_cards(deck ~= 0));
end

