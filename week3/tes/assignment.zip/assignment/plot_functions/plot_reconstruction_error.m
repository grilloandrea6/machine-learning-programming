function [] = plot_reconstruction_error(err)
%PLOT_RECONSTRUCTION_ERROR Summary of this function goes here
%   Detailed explanation goes here

end

